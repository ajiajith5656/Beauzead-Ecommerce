/**
 * PostConfirmation Lambda Trigger
 * Automatically assigns newly confirmed users to the appropriate Cognito group
 * based on the custom:signupType attribute
 */

const aws = require('aws-sdk');
const cognito = new aws.CognitoIdentityServiceProvider();

exports.handler = async (event, context) => {
  console.log('Event:', JSON.stringify(event));
  
  const userPoolId = event.userPoolId;
  const username = event.userName;
  
  // Get the custom attribute that indicates signup type
  const userAttributes = event.request.userAttributes || {};
  const signupType = userAttributes['custom:signupType'] || 'user';
  
  // Map signup type to Cognito group
  let groupName = 'user'; // default
  if (signupType === 'seller') {
    groupName = 'seller';
  } else if (signupType === 'admin') {
    groupName = 'admin';
  }
  
  try {
    // Add user to the appropriate group
    await cognito.adminAddUserToGroup({
      UserPoolId: userPoolId,
      Username: username,
      GroupName: groupName
    }).promise();
    
    console.log(`Successfully added ${username} to ${groupName} group`);
    
    return event;
  } catch (error) {
    console.error('Error adding user to group:', error);
    throw error;
  }
};

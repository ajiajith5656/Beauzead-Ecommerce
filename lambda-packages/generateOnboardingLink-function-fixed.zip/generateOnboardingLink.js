// Generate Stripe Onboarding Link Lambda Handler
const { generateStripeOnboardingLinkHandler } = require('./stripeConnectResolvers.js');

exports.handler = generateStripeOnboardingLinkHandler;
